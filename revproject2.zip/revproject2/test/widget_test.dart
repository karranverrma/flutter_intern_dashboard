import 'package:flutter/material.dart';

class LoginButton extends StatelessWidget {
  final VoidCallback onPressed;
  final String label;

  const LoginButton({
    super.key, // ✅ Cleaner syntax
    required this.onPressed,
    this.label = 'Login',
  });

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
        padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 12),
        backgroundColor: Colors.indigo,
      ),
      child: Text(label, style: const TextStyle(fontSize: 16)),
    );
  }
}