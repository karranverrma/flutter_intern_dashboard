import 'package:flutter/material.dart';

class LeaderboardScreen extends StatelessWidget {
  const LeaderboardScreen({super.key});

  final List<Map<String, dynamic>> leaderboard = const [
    {"name": "Aarav", "donation": 10000},
    {"name": "Karan", "donation": 5000},
    {"name": "Isha", "donation": 4500},
    {"name": "Ravi", "donation": 3000},
    {"name": "Sneha", "donation": 2500},
  ];

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: leaderboard.length,
      itemBuilder: (context, index) {
        final entry = leaderboard[index];
        return ListTile(
          leading: CircleAvatar(child: Text("${index + 1}")),
          title: Text(entry["name"]),
          subtitle: Text("₹${entry["donation"]} raised"),
          trailing: Icon(Icons.emoji_events, color: Colors.amber),
        );
      },
    );
  }
}