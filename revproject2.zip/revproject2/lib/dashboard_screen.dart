import 'package:flutter/material.dart';
import 'leaderboard_screen.dart';
import 'announcements_screen.dart';

class DashboardScreen extends StatefulWidget {
  final String userName;

  const DashboardScreen({super.key, required this.userName});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int _selectedIndex = 0;

  late final List<Widget> _screens;

  @override
  void initState() {
    super.initState();
    _screens = [
      Center(
        child: Text(
          "Welcome, ${widget.userName}!",
          style: TextStyle(fontSize: 24),
        ),
      ),
      const LeaderboardScreen(),
      const AnnouncementsScreen(),
    ];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Intern Dashboard")),
      body: _screens[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),
          BottomNavigationBarItem(icon: Icon(Icons.leaderboard), label: "Leaderboard"),
          BottomNavigationBarItem(icon: Icon(Icons.announcement), label: "Announcements"),
        ],
        onTap: (index) => setState(() => _selectedIndex = index),
      ),
    );
  }
}