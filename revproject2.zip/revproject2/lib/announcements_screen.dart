import 'package:flutter/material.dart';

class AnnouncementsScreen extends StatelessWidget {
  const AnnouncementsScreen({super.key});

  final List<String> announcements = const [
    "🎉 New Reward Unlocked: ₹200 Coupon for ₹5,000+ donations!",
    "📢 Leaderboard resets every Monday at 10 AM.",
    "🎯 Target: Raise ₹10,000 to unlock Gold Badge.",
    "🕒 Next webinar: Friday 5 PM on Zoom.",
  ];

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: announcements.length,
      itemBuilder: (context, index) {
        return Card(
          margin: EdgeInsets.all(12),
          child: ListTile(
            leading: Icon(Icons.campaign, color: Colors.indigo),
            title: Text(announcements[index]),
          ),
        );
      },
    );
  }
}