# 🧑‍💻 Flutter Intern Dashboard App

A sleek and functional dashboard app built with Flutter for intern management. Includes login, leaderboard, announcements, and navigation between screens.

---

## 🚀 Features

- 🔐 Login screen with email/password fields
- 📊 Dashboard with intern stats
- 🏆 Leaderboard showing top performers
- 📣 Announcements section
- 🔁 Seamless navigation between screens
- 🎨 Clean UI with Indigo theme

---

## 📦 Tech Stack

- **Flutter** 3.x
- **Dart**
- **Material Design**
- (Optional) Firebase for auth and data

---

## 🛠️ Setup Instructions

1. **Clone the repo**

   ```bash
   git clone https://github.com/yourusername/flutter-intern-dashboard.git
   cd flutter-intern-dashboard